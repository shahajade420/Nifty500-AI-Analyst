# Nifty 500 AI Analyst — Android prototype

An offline-first Kotlin + Jetpack Compose swing-trading research prototype.

## Current features
- Import daily OHLCV data from a CSV file using Android's document picker.
- Group and screen multiple symbols.
- Calculate EMA20, EMA50, RSI(14), MACD, volume ratio, 20-session return and 20-session breakout.
- Optional relative-strength comparison when `nifty_close` is supplied.
- Optional delivery and fundamental scoring when those columns are supplied.
- Rank the top 10 symbols.
- Open a stock detail view with indicators, score, coverage and signal notes.
- Offline research assistant for questions about loaded data and common indicators.
- No API keys, advertising SDKs, analytics SDKs, Firebase, Google Play Services or broker connection.

## Important limitations
This is a first working prototype, not a live market-data terminal and not a generative ChatGPT model. The assistant is rule-based and only uses data imported into the app. It does not automatically fetch NSE/SEBI data. Do not use the scores as standalone buy/sell instructions.

NSE's published MCP endpoints use Streamable HTTP and carry informational/non-commercial-use restrictions. Do not assume that access permits commercial redistribution, trading signals, or model training. Confirm permissions for your intended use before integrating any exchange data.

## Build
1. Install Android Studio and the Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Use JDK 17.
4. Allow Gradle to sync.
5. Select the `app` run configuration and run on an Android device or emulator.

To build an APK from a terminal:
```bash
./gradlew assembleDebug
```
The APK, once built, is normally at:
`app/build/outputs/apk/debug/app-debug.apk`

This source archive does not include the Gradle wrapper JAR. Android Studio can sync/build the project; alternatively generate a wrapper using a local Gradle installation:
```bash
gradle wrapper --gradle-version 8.9
```

## CSV format

Required header:
```csv
symbol,date,open,high,low,close,volume
```

Optional columns:
```csv
delivery_pct,nifty_close,revenue_growth,profit_growth,roce,debt_to_equity,promoter_change,fii_change
```

Use one row per symbol per trading day. At least 55 daily rows per symbol are required for ranking. Dates should use `YYYY-MM-DD`. Optional percentage values are percentage points (for example, `42.5` means 42.5%).

A sample file is provided in `sample-data/demo_ohlcv.csv`. It contains synthetic DEMO symbols and must not be mistaken for actual exchange data.

## Scoring notes
The score is normalised to the available indicators. Data coverage is displayed separately, so a score based on fewer available fields is not presented as equivalent to a fully populated score. The weights and thresholds are initial hypotheses and must be validated with out-of-sample backtesting, corporate-action adjustments, liquidity checks, transaction costs and slippage.

## F-Droid preparation
The project is intended to avoid proprietary SDKs and use a permissive open-source license. F-Droid inclusion is not automatic: publish a maintained public source repository, ensure all dependencies/tooling meet the current inclusion policy, provide build metadata, and submit it for review. A listing decision belongs to F-Droid maintainers.

## License
MIT. See `LICENSE`.
