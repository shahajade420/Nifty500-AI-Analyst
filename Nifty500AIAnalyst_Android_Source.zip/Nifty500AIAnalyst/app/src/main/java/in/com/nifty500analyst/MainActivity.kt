package in.com.nifty500analyst

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { NiftyAnalystApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NiftyAnalystApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tab by remember { mutableStateOf("Dashboard") }
    var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }
    var analyses by remember { mutableStateOf<List<StockAnalysis>>(emptyList()) }
    var status by remember { mutableStateOf("Import a historical OHLCV CSV to begin.") }
    var selected by remember { mutableStateOf<StockAnalysis?>(null) }

    val csvPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input)).readText()
                } ?: error("Unable to open selected file.")
                val parsed = CsvImporter.parse(text)
                candles = parsed
                analyses = Screener.analyse(parsed)
                val symbols = parsed.map { it.symbol }.distinct().size
                status = "Imported ${parsed.size} rows across $symbols symbols. ${analyses.size} symbols have enough history for screening."
            } catch (e: Exception) {
                status = "Import failed: ${e.message ?: "Unknown error"}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Nifty 500 AI Analyst", fontWeight = FontWeight.Bold)
                        Text("Swing trading research • Offline prototype", style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf("Dashboard", "Scanner", "Assistant", "Data").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Text(when (item) {
                            "Dashboard" -> "⌂"
                            "Scanner" -> "↗"
                            "Assistant" -> "✦"
                            else -> "▤"
                        }) },
                        label = { Text(item) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                "Dashboard" -> DashboardScreen(analyses, candles.size, status) { tab = "Scanner" }
                "Scanner" -> ScannerScreen(analyses, onSelect = { selected = it })
                "Assistant" -> AssistantScreen(analyses)
                else -> DataScreen(status, candles.size, analyses.size) {
                    csvPicker.launch(arrayOf("text/*", "application/vnd.ms-excel", "text/csv", "application/csv"))
                }
            }
        }
    }

    selected?.let { stock ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(stock.symbol) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Latest close: ${money(stock.close)}")
                    Text("Date: ${stock.latestDate}")
                    Text("Screening score: ${stock.score.fmt()} / 100")
                    Text("Data coverage: ${stock.coverage.fmt()} / 100")
                    Text("RSI(14): ${stock.rsi14.fmt()}")
                    Text("EMA 20: ${money(stock.ema20)}")
                    Text("EMA 50: ${money(stock.ema50)}")
                    Text("MACD: ${stock.macd.fmt()} | Signal: ${stock.macdSignal.fmt()}")
                    Text("Volume / 20-day average: ${stock.volumeRatio.fmt()}x")
                    Text("20-session return: ${stock.return20d.fmt()}%")
                    Text("20-session breakout: ${if (stock.breakout) "Yes" else "No"}")
                    stock.deliveryPct?.let { Text("Delivery: ${it.fmt()}%") }
                    Spacer(Modifier.height(8.dp))
                    Text("Signal notes", fontWeight = FontWeight.Bold)
                    stock.reasons.forEach { Text("• $it") }
                    Spacer(Modifier.height(8.dp))
                    Text("This is a screening result, not a buy/sell recommendation. Validate liquidity, news, risk and market conditions.")
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Close") } }
        )
    }
}

@Composable
fun DashboardScreen(
    analyses: List<StockAnalysis>,
    rowCount: Int,
    status: String,
    onOpenScanner: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Market research overview", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Rows loaded", rowCount.toString(), Modifier.weight(1f))
            MetricCard("Stocks screened", analyses.size.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        MetricCard("Highest screening score", analyses.firstOrNull()?.let { "${it.symbol} • ${it.score.fmt()}" } ?: "No data", Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        Text(status, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onOpenScanner, enabled = analyses.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text("View swing trading rankings")
        }
        Spacer(Modifier.height(18.dp))
        Text("How the score works", fontWeight = FontWeight.Bold)
        Text("The prototype scores EMA trend, RSI, MACD, relative strength (when benchmark data is supplied), volume, breakout, delivery and selected fundamental fields. Missing optional fields are excluded and the data coverage is shown separately.")
        Spacer(Modifier.height(10.dp))
        Text("Minimum history: 55 daily rows per stock. Use adjusted prices consistently and avoid mixing split-adjusted and unadjusted series.")
    }
}

@Composable
fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ScannerScreen(analyses: List<StockAnalysis>, onSelect: (StockAnalysis) -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Top swing candidates", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ranked by the prototype score; not a prediction of future returns.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        if (analyses.isEmpty()) {
            EmptyMessage("No ranked stocks yet. Go to Data and import a CSV with at least 55 daily observations per symbol.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(analyses.take(10)) { stock ->
                    Card(Modifier.fillMaxWidth().clickable { onSelect(stock) }) {
                        Column(Modifier.padding(12.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(stock.symbol, fontWeight = FontWeight.Bold)
                                Text("${stock.score.fmt()} / 100", fontWeight = FontWeight.Bold)
                            }
                            Text("₹${money(stock.close)} • RSI ${stock.rsi14.fmt()} • Vol ${stock.volumeRatio.fmt()}x")
                            Text("20D return ${stock.return20d.fmt()}% • Coverage ${stock.coverage.fmt()}%", style = MaterialTheme.typography.bodySmall)
                            if (stock.breakout) Text("20-session breakout detected", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AssistantScreen(analyses: List<StockAnalysis>) {
    var question by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Research assistant", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Offline assistant: answers from the imported screening results. It is not a generative ChatGPT model.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (messages.isEmpty()) {
                item {
                    Card {
                        Text(
                            "Try: “top 10”, “why is ABC ranked?”, “show breakout stocks”, or “what does RSI mean?”",
                            Modifier.padding(12.dp)
                        )
                    }
                }
            }
            items(messages) { (user, message) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (user) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Text((if (user) "You: " else "Analyst: ") + message, Modifier.padding(12.dp))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = question,
                onValueChange = { question = it },
                modifier = Modifier.weight(1f),
                label = { Text("Ask about your stocks") },
                singleLine = true
            )
            Button(onClick = {
                val q = question.trim()
                if (q.isNotEmpty()) {
                    messages.add(true to q)
                    messages.add(false to answerQuestion(q, analyses))
                    question = ""
                }
            }) { Text("Send") }
        }
    }
}

fun answerQuestion(question: String, analyses: List<StockAnalysis>): String {
    val q = question.lowercase()
    if (analyses.isEmpty()) return "No stock data is loaded yet. Import a CSV from the Data tab first."
    if ("rsi" in q) return "RSI measures recent price momentum on a 0–100 scale. This prototype gives more points to RSI between 50 and 65; very high RSI can also indicate an extended move."
    if ("macd" in q) return "MACD compares short- and long-term exponential moving averages. This prototype rewards a positive MACD line above its signal line."
    if ("ema" in q) return "EMA is an exponentially weighted moving average. The scanner checks price versus EMA20 and the relationship between EMA20 and EMA50."
    if ("top" in q || "rank" in q || "best" in q) {
        return analyses.take(10).mapIndexed { i, s ->
            "${i + 1}. ${s.symbol}: ${s.score.fmt()}/100, close ₹${money(s.close)}, RSI ${s.rsi14.fmt()}, volume ${s.volumeRatio.fmt()}x"
        }.joinToString("\n")
    }
    if ("breakout" in q) {
        val list = analyses.filter { it.breakout }.take(10)
        return if (list.isEmpty()) "No 20-session closing breakouts were found in the imported data."
        else "20-session breakouts:\n" + list.joinToString("\n") { "${it.symbol}: score ${it.score.fmt()}" }
    }
    val symbol = analyses.firstOrNull { q.contains(it.symbol.lowercase()) }
    if (symbol != null) {
        return "${symbol.symbol}: score ${symbol.score.fmt()}/100; close ₹${money(symbol.close)}; RSI ${symbol.rsi14.fmt()}; EMA20 ₹${money(symbol.ema20)}; EMA50 ₹${money(symbol.ema50)}; volume ${symbol.volumeRatio.fmt()}x; 20-session return ${symbol.return20d.fmt()}%. Notes: ${symbol.reasons.joinToString("; ")}. This is a screening summary, not investment advice."
    }
    return "I can summarise the imported top 10, explain RSI/MACD/EMA, identify 20-session breakouts, or analyse a symbol present in your CSV. Try asking “top 10” or “why is ${analyses.first().symbol} ranked?”"
}

@Composable
fun DataScreen(status: String, rows: Int, stocks: Int, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Market data", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(status)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Rows", rows.toString(), Modifier.weight(1f))
            MetricCard("Symbols", stocks.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("Import OHLCV CSV") }
        Spacer(Modifier.height(18.dp))
        Text("Required CSV columns", fontWeight = FontWeight.Bold)
        Text("symbol,date,open,high,low,close,volume")
        Spacer(Modifier.height(8.dp))
        Text("Optional columns")
        Text("delivery_pct,nifty_close,revenue_growth,profit_growth,roce,debt_to_equity,promoter_change,fii_change")
        Spacer(Modifier.height(8.dp))
        Text("Use one row per symbol per trading day. Date format should sort chronologically, preferably YYYY-MM-DD. Numeric percentages should be entered as percentage points (e.g. 42.5, not 0.425).")
        Spacer(Modifier.height(14.dp))
        Text("Data source note", fontWeight = FontWeight.Bold)
        Text("This version does not scrape NSE or SEBI and does not connect to an unofficial endpoint. Import only datasets you are authorised to use. NSE's MCP service has specific informational/non-commercial conditions; review those before integrating it.")
    }
}

@Composable
fun EmptyMessage(message: String) {
    Card(Modifier.fillMaxWidth()) { Text(message, Modifier.padding(16.dp)) }
}

fun Double.fmt(): String = String.format(Locale.US, "%.1f", this)
fun money(value: Double): String = String.format(Locale.US, "%,.2f", value)
