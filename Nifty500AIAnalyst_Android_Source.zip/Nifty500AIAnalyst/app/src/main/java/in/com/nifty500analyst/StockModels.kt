package in.com.nifty500analyst

data class Candle(
    val symbol: String,
    val date: String,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val deliveryPct: Double? = null,
    val niftyClose: Double? = null,
    val revenueGrowth: Double? = null,
    val profitGrowth: Double? = null,
    val roce: Double? = null,
    val debtToEquity: Double? = null,
    val promoterChange: Double? = null,
    val fiiChange: Double? = null
)

data class StockAnalysis(
    val symbol: String,
    val latestDate: String,
    val close: Double,
    val ema20: Double,
    val ema50: Double,
    val rsi14: Double,
    val macd: Double,
    val macdSignal: Double,
    val volumeRatio: Double,
    val return20d: Double,
    val score: Double,
    val coverage: Double,
    val breakout: Boolean,
    val deliveryPct: Double?,
    val reasons: List<String>
)
