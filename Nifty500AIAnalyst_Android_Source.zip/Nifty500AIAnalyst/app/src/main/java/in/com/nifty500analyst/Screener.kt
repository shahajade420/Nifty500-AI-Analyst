package in.com.nifty500analyst

import kotlin.math.abs
import kotlin.math.max

object Screener {
    private fun emaSeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val alpha = 2.0 / (period + 1.0)
        val result = mutableListOf<Double>()
        var current = values.first()
        result.add(current)
        values.drop(1).forEach {
            current = alpha * it + (1.0 - alpha) * current
            result.add(current)
        }
        return result
    }

    private fun rsi(values: List<Double>, period: Int = 14): Double {
        if (values.size <= period) return 50.0
        val changes = values.zipWithNext { a, b -> b - a }.takeLast(period)
        val gains = changes.filter { it > 0 }.sum() / period
        val losses = changes.filter { it < 0 }.sumOf { abs(it) } / period
        if (losses == 0.0) return 100.0
        val rs = gains / losses
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun analyse(allCandles: List<Candle>): List<StockAnalysis> {
        return allCandles.groupBy { it.symbol }.mapNotNull { (symbol, unsorted) ->
            val rows = unsorted.sortedBy { it.date }
            if (rows.size < 55) return@mapNotNull null

            val closes = rows.map { it.close }
            val volumes = rows.map { it.volume }
            val last = rows.last()
            val ema20Series = emaSeries(closes, 20)
            val ema50Series = emaSeries(closes, 50)
            val ema20 = ema20Series.last()
            val ema50 = ema50Series.last()
            val rsi14 = rsi(closes)

            val ema12 = emaSeries(closes, 12)
            val ema26 = emaSeries(closes, 26)
            val macdSeries = ema12.zip(ema26) { a, b -> a - b }
            val macdSignal = emaSeries(macdSeries, 9).last()
            val macd = macdSeries.last()

            val previousVolumes = volumes.dropLast(1).takeLast(20)
            val avgVolume = previousVolumes.average().takeIf { previousVolumes.isNotEmpty() } ?: 0.0
            val volumeRatio = if (avgVolume > 0) last.volume / avgVolume else 0.0

            val oldClose = closes[closes.size - 21]
            val return20 = if (oldClose != 0.0) (last.close / oldClose - 1.0) * 100.0 else 0.0

            val previous20High = rows.dropLast(1).takeLast(20).maxOf { it.high }
            val breakout = last.close > previous20High

            val benchmarkRows = rows.takeLast(21).mapNotNull { it.niftyClose }
            val relativeAvailable = benchmarkRows.size >= 21 && benchmarkRows.first() > 0
            val benchmarkReturn = if (relativeAvailable)
                (benchmarkRows.last() / benchmarkRows.first() - 1.0) * 100.0 else null

            val components = mutableListOf<Pair<Double, Double>>()
            val reasons = mutableListOf<String>()

            val trendPts = when {
                last.close > ema20 && ema20 > ema50 -> 15.0
                last.close > ema20 -> 8.0
                else -> 0.0
            }
            components.add(trendPts to 15.0)
            if (trendPts > 0) reasons.add("Price above key EMA trend")

            val rsiPts = when {
                rsi14 in 50.0..65.0 -> 10.0
                rsi14 in 45.0..70.0 -> 6.0
                else -> 0.0
            }
            components.add(rsiPts to 10.0)
            if (rsiPts > 0) reasons.add("RSI momentum in a constructive range")

            val macdPts = when {
                macd > macdSignal && macd > 0 -> 10.0
                macd > macdSignal -> 7.0
                macd > 0 -> 4.0
                else -> 0.0
            }
            components.add(macdPts to 10.0)
            if (macdPts > 0) reasons.add("MACD momentum positive")

            val volumePts = when {
                volumeRatio >= 1.5 -> 15.0
                volumeRatio >= 1.2 -> 10.0
                volumeRatio >= 1.0 -> 5.0
                else -> 0.0
            }
            components.add(volumePts to 15.0)
            if (volumePts > 0) reasons.add("Volume above its 20-session average")

            if (relativeAvailable && benchmarkReturn != null) {
                val relative = return20 - benchmarkReturn
                val pts = when {
                    relative >= 3.0 -> 15.0
                    relative > 0.0 -> 10.0
                    else -> 3.0
                }
                components.add(pts to 15.0)
                if (pts >= 10) reasons.add("Outperforming Nifty benchmark")
            }

            val breakoutPts = when {
                breakout -> 10.0
                last.close >= previous20High * 0.98 -> 5.0
                else -> 0.0
            }
            components.add(breakoutPts to 10.0)
            if (breakout) reasons.add("Close above previous 20-session high")

            last.deliveryPct?.let {
                val pts = when {
                    it >= 50 -> 10.0
                    it >= 35 -> 7.0
                    it >= 20 -> 4.0
                    else -> 0.0
                }
                components.add(pts to 10.0)
                if (pts >= 7) reasons.add("Delivery percentage is relatively strong")
            }

            val fundamentalFields = listOf(last.roce, last.profitGrowth, last.debtToEquity)
            if (fundamentalFields.any { it != null }) {
                var pts = 0.0
                last.roce?.let { pts += when { it >= 20 -> 5.0; it >= 15 -> 3.0; else -> 0.0 } }
                last.profitGrowth?.let { pts += when { it >= 15 -> 5.0; it > 0 -> 3.0; else -> 0.0 } }
                last.debtToEquity?.let { pts += when { it <= 0.5 -> 5.0; it <= 1.0 -> 3.0; else -> 0.0 } }
                val maxFundamental = (if (last.roce != null) 5.0 else 0.0) +
                    (if (last.profitGrowth != null) 5.0 else 0.0) +
                    (if (last.debtToEquity != null) 5.0 else 0.0)
                components.add(pts to maxFundamental)
                if (pts >= 8) reasons.add("Available fundamental metrics are supportive")
            }

            val available = components.sumOf { it.second }
            val earned = components.sumOf { it.first }
            val score = if (available > 0) earned / available * 100.0 else 0.0
            val coverage = available
            StockAnalysis(
                symbol, last.date, last.close, ema20, ema50, rsi14, macd, macdSignal,
                volumeRatio, return20, score, coverage, breakout, last.deliveryPct,
                reasons.ifEmpty { listOf("No strong positive signal in the selected indicators") }
            )
        }.sortedByDescending { it.score }
    }
}
