package in.com.nifty500analyst

object CsvImporter {
    private fun splitCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    cell.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> {
                    out.add(cell.toString().trim()); cell.clear()
                }
                else -> cell.append(c)
            }
            i++
        }
        out.add(cell.toString().trim())
        return out
    }

    private fun Double?.orNull(): Double? = this

    fun parse(csv: String): List<Candle> {
        val lines = csv.trim().lines().filter { it.isNotBlank() }
        require(lines.size >= 2) { "CSV must contain a header and at least one data row." }

        val headers = splitCsvLine(lines.first()).map { it.trim().lowercase() }
        fun index(vararg names: String): Int =
            headers.indexOfFirst { header -> names.any { it.equals(header, ignoreCase = true) } }

        val iSymbol = index("symbol", "ticker")
        val iDate = index("date", "timestamp")
        val iOpen = index("open")
        val iHigh = index("high")
        val iLow = index("low")
        val iClose = index("close", "adj close", "adj_close")
        val iVolume = index("volume", "vol")
        require(listOf(iSymbol, iDate, iOpen, iHigh, iLow, iClose, iVolume).all { it >= 0 }) {
            "Required columns: symbol,date,open,high,low,close,volume"
        }

        fun optionalIndex(vararg names: String) = index(*names)
        val iDelivery = optionalIndex("delivery_pct", "delivery percentage", "delivery_percent")
        val iNifty = optionalIndex("nifty_close", "benchmark_close")
        val iRevenue = optionalIndex("revenue_growth", "sales_growth")
        val iProfit = optionalIndex("profit_growth", "pat_growth")
        val iRoce = optionalIndex("roce")
        val iDebt = optionalIndex("debt_to_equity", "debt_equity")
        val iPromoter = optionalIndex("promoter_change", "promoter_holding_change")
        val iFii = optionalIndex("fii_change", "fii_holding_change")

        fun value(cells: List<String>, idx: Int): String =
            if (idx >= 0 && idx < cells.size) cells[idx].trim() else ""

        fun number(cells: List<String>, idx: Int): Double? {
            if (idx < 0) return null
            return value(cells, idx).replace("%", "").replace(",", "").toDoubleOrNull()
        }

        val result = mutableListOf<Candle>()
        lines.drop(1).forEachIndexed { rowNo, line ->
            val c = splitCsvLine(line)
            try {
                val symbol = value(c, iSymbol).uppercase()
                val date = value(c, iDate)
                if (symbol.isBlank() || date.isBlank()) return@forEachIndexed
                val open = number(c, iOpen) ?: return@forEachIndexed
                val high = number(c, iHigh) ?: return@forEachIndexed
                val low = number(c, iLow) ?: return@forEachIndexed
                val close = number(c, iClose) ?: return@forEachIndexed
                val volume = number(c, iVolume) ?: return@forEachIndexed
                result.add(
                    Candle(
                        symbol, date, open, high, low, close, volume,
                        number(c, iDelivery), number(c, iNifty),
                        number(c, iRevenue), number(c, iProfit), number(c, iRoce),
                        number(c, iDebt), number(c, iPromoter), number(c, iFii)
                    )
                )
            } catch (_: Exception) {
                // Skip malformed rows; the import summary reports accepted row count.
            }
        }
        require(result.isNotEmpty()) { "No valid rows found. Check the CSV column names and values." }
        return result
    }
}
